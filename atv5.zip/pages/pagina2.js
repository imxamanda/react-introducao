import 'bootstrap/dist/css/bootstrap.min.css';
import { Container } from 'react-bootstrap';
//import Cabecalho from "../components/Cabecalho"
import Rodape from  "../components/Rodape"
import React from 'react'
import Navbar from '../components/Navbar';

const pagina2 = () => {

  
  return (
    <>
    <Navbar/>

    <Container>
    <h1>Página 2</h1>
    
    </Container>
    </>
  )
}

export default pagina2 